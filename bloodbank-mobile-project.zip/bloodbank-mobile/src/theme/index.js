// الثيم: الألوان والخطوط والظلال والمسافات. بنستخدمها بكل الشاشات بدل ما نكتب الأرقام كل مرة.
// أي تعديل على شكل التطبيق (لون، خط) بيتم من هون بس.
import { I18nManager } from 'react-native';

export const colors = {
  primary: '#C4122F', // الأحمر الأساسي
  primaryDark: '#8E0A1E',
  primarySoft: '#FCE4E8', // أحمر فاتح للخلفيات
  bg: '#FFF7F7',
  card: '#FFFFFF',
  text: '#2B1B1E',
  textLight: '#7A6A6D',
  border: '#F0DDE0',
  success: '#1E9E5A',
  successSoft: '#E3F6EC',
  warning: '#E08A00',
  warningSoft: '#FFF2D9',
  info: '#2F6FDE',
  infoSoft: '#E5EEFD',
  white: '#FFFFFF',
};

// التدرجات اللونية (من لون لتاني). كل واحد = مصفوفة ألوان.
export const gradients = {
  primary: ['#E0334C', '#A60E25'],
  dark: ['#6B0817', '#2A0309'],
  soft: ['#FFF7F7', '#FFE9EC'],
  welcome: ['#FFF6F7', '#FFD9DF', '#C4122F', '#5A0714'],
};

// أسماء الخطوط (Cairo). بالموبايل لازم نختار الخط حسب الوزن، مش fontWeight.
export const fonts = {
  regular: 'Cairo_400Regular',
  semi: 'Cairo_600SemiBold',
  bold: 'Cairo_700Bold',
  black: 'Cairo_800ExtraBold',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };
export const radius = { sm: 10, md: 16, lg: 22, xl: 30, full: 999 };
export const fontSize = { xs: 11, sm: 13, md: 15, lg: 18, xl: 22, xxl: 28 };

// الظلال: بتعطي الكروت إحساس العمق (shadow* للآيفون، elevation للأندرويد)
export const shadow = {
  card: {
    shadowColor: '#8E0A1E',
    shadowOpacity: 0.1,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 8 },
    elevation: 5,
  },
  button: {
    shadowColor: '#C4122F',
    shadowOpacity: 0.35,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
};

// محاذاة النص حسب الاتجاه (عربي = يمين، إنجليزي = يسار)
export const textAlign = I18nManager.isRTL ? 'right' : 'left';
