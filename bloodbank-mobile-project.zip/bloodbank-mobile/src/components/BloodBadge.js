// دائرة فيها فصيلة الدم (مثل O+)
import { StyleSheet, View } from 'react-native';
import AppText from './AppText';
import { colors, fonts } from '../theme';

export default function BloodBadge({ type, size = 52 }) {
  return (
    <View style={[styles.circle, { width: size, height: size, borderRadius: size / 2 }]}>
      <AppText color={colors.primary} style={{ fontFamily: fonts.black, fontSize: size * 0.34, lineHeight: size * 0.6 }}>
        {type}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  circle: { backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' },
});
