// شارة صغيرة: حالة الطلب (مطلوب / في الطريق / تم) أو الاستعجال (عاجل / عادي)
import { StyleSheet, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import AppText from './AppText';
import { colors, radius, spacing } from '../theme';

// لون الخلفية والنص لكل قيمة
const PALETTE = {
  PENDING: { bg: colors.warningSoft, text: colors.warning },
  ON_THE_WAY: { bg: colors.infoSoft, text: colors.info },
  DONE: { bg: colors.successSoft, text: colors.success },
  URGENT: { bg: colors.primarySoft, text: colors.primary },
  NORMAL: { bg: '#F1ECEC', text: colors.textLight },
};

// kind: 'status' أو 'urgency'. value: الكود (PENDING, URGENT...)
export default function StatusBadge({ kind = 'status', value }) {
  const { t } = useTranslation();
  const palette = PALETTE[value] || PALETTE.NORMAL;

  return (
    <View style={[styles.badge, { backgroundColor: palette.bg }]}>
      <AppText variant="caption" color={palette.text} style={styles.text}>
        {t(`${kind}.${value}`)}
      </AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: { paddingHorizontal: spacing.sm + 2, paddingVertical: 1, borderRadius: radius.full },
  text: { fontSize: 12 },
});
