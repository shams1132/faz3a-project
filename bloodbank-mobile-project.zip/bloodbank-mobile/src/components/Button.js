// زر عام. variant: 'primary' (تدرج أحمر) / 'outline' (إطار) / 'light' (أبيض، للخلفيات الحمرا)
import { ActivityIndicator, Pressable, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppText from './AppText';
import { colors, gradients, radius, shadow, spacing } from '../theme';

export default function Button({ title, onPress, variant = 'primary', loading = false, disabled = false, icon, style }) {
  const isPrimary = variant === 'primary';
  const textColor = isPrimary ? colors.white : colors.primary;

  // محتوى الزر: دائرة تحميل، أو (أيقونة اختيارية + النص)
  const content = loading ? (
    <ActivityIndicator color={textColor} />
  ) : (
    <View style={styles.row}>
      {icon ? <Ionicons name={icon} size={20} color={textColor} /> : null}
      <AppText variant="button" color={textColor}>
        {title}
      </AppText>
    </View>
  );

  return (
    <Pressable
      onPress={onPress}
      disabled={disabled || loading}
      // pressed = true أثناء الضغط: بنصغّر الزر شوي ونخفف شفافيته
      style={({ pressed }) => [pressed && styles.pressed, (disabled || loading) && styles.disabled, style]}
    >
      {isPrimary ? (
        <LinearGradient colors={gradients.primary} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.inner, shadow.button]}>
          {content}
        </LinearGradient>
      ) : (
        <View style={[styles.inner, variant === 'outline' ? styles.outline : styles.light]}>{content}</View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  inner: { minHeight: 52, borderRadius: radius.full, paddingHorizontal: spacing.lg, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  outline: { borderWidth: 1.5, borderColor: colors.primary, backgroundColor: 'rgba(255,255,255,0.6)' },
  light: { backgroundColor: colors.white },
  pressed: { opacity: 0.85, transform: [{ scale: 0.98 }] },
  disabled: { opacity: 0.5 },
});
