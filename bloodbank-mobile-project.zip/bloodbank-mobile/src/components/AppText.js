// نص التطبيق: بدل ما نستخدم Text العادي ونكرر الخط والحجم، بنستخدم هاد المكون.
// variant بيحدد الشكل: display (ضخم) / title / heading / body / caption / button
import { Text } from 'react-native';
import { colors, fonts, fontSize } from '../theme';

const VARIANTS = {
  display: { fontFamily: fonts.black, fontSize: fontSize.xxl, lineHeight: 42 },
  title: { fontFamily: fonts.bold, fontSize: fontSize.xl, lineHeight: 32 },
  heading: { fontFamily: fonts.bold, fontSize: fontSize.lg, lineHeight: 28 },
  body: { fontFamily: fonts.regular, fontSize: fontSize.md, lineHeight: 24 },
  bodyBold: { fontFamily: fonts.semi, fontSize: fontSize.md, lineHeight: 24 },
  caption: { fontFamily: fonts.regular, fontSize: fontSize.sm, lineHeight: 20, color: colors.textLight },
  button: { fontFamily: fonts.bold, fontSize: fontSize.md, lineHeight: 24 },
};

// color: لون النص. align: محاذاة. style: تنسيق إضافي. باقي الخصائص بتنمرر لـ Text.
export default function AppText({ variant = 'body', color, align, style, children, ...rest }) {
  return (
    <Text
      style={[{ color: colors.text }, VARIANTS[variant], color && { color }, align && { textAlign: align }, style]}
      {...rest}
    >
      {children}
    </Text>
  );
}
