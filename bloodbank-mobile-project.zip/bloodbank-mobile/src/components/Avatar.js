// صورة رمزية: دائرة بتدرج أحمر فيها أول حرف من الاسم (لحد ما نضيف صور حقيقية).
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AppText from './AppText';
import { colors, gradients } from '../theme';

export default function Avatar({ name = '', size = 48 }) {
  const initial = name.trim().charAt(0).toUpperCase();
  return (
    <LinearGradient
      colors={gradients.primary}
      style={[styles.circle, { width: size, height: size, borderRadius: size / 2 }]}
    >
      <AppText variant="heading" color={colors.white} style={{ fontSize: size * 0.42, lineHeight: size * 0.7 }}>
        {initial}
      </AppText>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({ circle: { alignItems: 'center', justifyContent: 'center' } });
