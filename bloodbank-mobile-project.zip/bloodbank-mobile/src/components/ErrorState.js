// رسالة خطأ مع زر إعادة المحاولة
import { StyleSheet, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import AppText from './AppText';
import Button from './Button';
import { colors, spacing } from '../theme';

export default function ErrorState({ onRetry }) {
  const { t } = useTranslation();
  return (
    <View style={styles.container}>
      <AppText color={colors.textLight}>{t('common.loadError')}</AppText>
      <Button title={t('common.retry')} onPress={onRetry} variant="outline" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.lg, gap: spacing.md },
});
