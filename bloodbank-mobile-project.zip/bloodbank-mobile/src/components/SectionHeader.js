// عنوان قسم (مثل "طلبات عاجلة") مع رابط "عرض الكل" اختياري
import { Pressable, StyleSheet, View } from 'react-native';
import AppText from './AppText';
import { colors, spacing } from '../theme';

export default function SectionHeader({ title, actionLabel, onAction }) {
  return (
    <View style={styles.row}>
      <AppText variant="heading">{title}</AppText>
      {actionLabel ? (
        <Pressable onPress={onAction} hitSlop={10}>
          <AppText variant="caption" color={colors.primary}>{actionLabel}</AppText>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm },
});
