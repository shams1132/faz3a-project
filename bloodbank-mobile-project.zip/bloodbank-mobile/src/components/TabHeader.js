// عنوان شاشات التبويبات (بدل شريط العنوان الافتراضي). بيحترم النوتش وشريط الحالة.
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AppText from './AppText';
import { spacing } from '../theme';

export default function TabHeader({ title, right }) {
  const insets = useSafeAreaInsets(); // مسافات الأمان (النوتش)
  return (
    <View style={[styles.row, { paddingTop: insets.top + spacing.sm }]}>
      <AppText variant="title">{title}</AppText>
      {right}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingBottom: spacing.md },
});
