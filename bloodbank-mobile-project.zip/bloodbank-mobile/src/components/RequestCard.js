// كارد طلب الدم (بالرئيسية وبقائمة الطلبات)
import { I18nManager, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from './AppText';
import BloodBadge from './BloodBadge';
import Card from './Card';
import ProgressBar from './ProgressBar';
import StatusBadge from './StatusBadge';
import { timeAgo } from '../utils/dateHelpers';
import { colors, spacing } from '../theme';

export default function RequestCard({ request, onPress }) {
  const { t } = useTranslation();

  return (
    <Pressable onPress={onPress} style={({ pressed }) => [pressed && styles.pressed]}>
      <Card style={styles.card}>
        <BloodBadge type={request.bloodType} />

        <View style={styles.info}>
          <AppText variant="bodyBold">{t('hospital.name')}</AppText>
          <AppText variant="caption">
            {t('common.units', { count: request.unitsNeeded })} • {timeAgo(request.createdAt, t)}
          </AppText>
          {/* شريط تقدم صغير: كم تم وكم بالطريق من المطلوب */}
          <ProgressBar done={request.unitsDone} onTheWay={request.unitsOnTheWay} total={request.unitsNeeded} />
          <View style={styles.badges}>
            <StatusBadge kind="urgency" value={request.urgency} />
            <StatusBadge kind="status" value={request.status} />
          </View>
        </View>

        {/* السهم بينعكس حسب الاتجاه */}
        <Ionicons name={I18nManager.isRTL ? 'chevron-back' : 'chevron-forward'} size={20} color={colors.textLight} />
      </Card>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.md },
  pressed: { opacity: 0.9, transform: [{ scale: 0.99 }] },
  info: { flex: 1, gap: 6 },
  badges: { flexDirection: 'row', gap: spacing.sm },
});
