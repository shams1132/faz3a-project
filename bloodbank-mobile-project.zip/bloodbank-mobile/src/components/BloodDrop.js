// رسمة قطرة الدم مع القلب والنبض (مرسومة بـ SVG، فبتكبر بدون ما تخرب).
// animated = true بتخلي القطرة "تنبض" بحركة خفيفة.
import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';
import Svg, { Defs, LinearGradient, Path, Stop } from 'react-native-svg';

export default function BloodDrop({ size = 120, animated = false }) {
  const scale = useRef(new Animated.Value(1)).current;

  // حركة النبض: بتكبر شوي وبترجع، وبتتكرر للأبد
  useEffect(() => {
    if (!animated) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(scale, { toValue: 1.07, duration: 700, useNativeDriver: true }),
        Animated.timing(scale, { toValue: 1, duration: 700, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [animated]);

  return (
    <Animated.View style={{ transform: [{ scale }] }}>
      <Svg width={size} height={size * 1.25} viewBox="0 0 100 125">
        <Defs>
          <LinearGradient id="dropGradient" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor="#F2506A" />
            <Stop offset="1" stopColor="#8E0A1E" />
          </LinearGradient>
        </Defs>
        {/* جسم القطرة */}
        <Path
          d="M50 4 C50 4 8 52 8 80 C8 103 27 121 50 121 C73 121 92 103 92 80 C92 52 50 4 50 4 Z"
          fill="url(#dropGradient)"
        />
        {/* لمعة على جنب القطرة */}
        <Path d="M26 80 C26 68 32 58 39 49" stroke="#FFFFFF" strokeOpacity="0.45" strokeWidth="5" strokeLinecap="round" fill="none" />
        {/* القلب */}
        <Path
          d="M50 100 L33 83 C27 76 29 66 37 65 C42 64.5 47 67 50 72 C53 67 58 64.5 63 65 C71 66 73 76 67 83 Z"
          stroke="#FFFFFF"
          strokeWidth="3"
          strokeLinejoin="round"
          fill="none"
        />
        {/* خط النبض داخل القلب */}
        <Path d="M38 82 H45 L48 76 L52 90 L55 82 H62" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      </Svg>
    </Animated.View>
  );
}
