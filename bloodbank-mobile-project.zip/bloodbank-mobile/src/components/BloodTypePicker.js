// اختيار فصيلة الدم من 8 خيارات (شبكة من الأزرار)
import { Pressable, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AppText from './AppText';
import { BLOOD_TYPES } from '../config';
import { colors, fonts, gradients, radius, spacing } from '../theme';

export default function BloodTypePicker({ value, onChange, error }) {
  return (
    <View>
      <View style={styles.grid}>
        {BLOOD_TYPES.map((type) => {
          const selected = value === type; // هل هاي الفصيلة هي المختارة؟
          return (
            <Pressable key={type} onPress={() => onChange(type)} style={styles.item}>
              {selected ? (
                <LinearGradient colors={gradients.primary} style={styles.chip}>
                  <AppText color={colors.white} style={styles.chipText}>{type}</AppText>
                </LinearGradient>
              ) : (
                <View style={[styles.chip, styles.chipIdle]}>
                  <AppText style={styles.chipText}>{type}</AppText>
                </View>
              )}
            </Pressable>
          );
        })}
      </View>
      {error ? <AppText variant="caption" color={colors.primary} style={styles.error}>{error}</AppText> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  item: { width: '23%' },
  chip: { paddingVertical: 10, alignItems: 'center', borderRadius: radius.md },
  chipIdle: { backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border },
  chipText: { fontFamily: fonts.black, lineHeight: 24 },
  error: { marginTop: spacing.xs },
});
