// شريط تقدم: done (تم) + onTheWay (في الطريق) من total (المطلوب)
import { StyleSheet, View } from 'react-native';
import { colors, radius } from '../theme';

export default function ProgressBar({ done = 0, onTheWay = 0, total = 1 }) {
  const donePct = Math.min(100, (done / total) * 100);
  const wayPct = Math.min(100 - donePct, (onTheWay / total) * 100);
  return (
    <View style={styles.track}>
      <View style={[styles.done, { width: `${donePct}%` }]} />
      <View style={[styles.way, { width: `${wayPct}%` }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  track: { flexDirection: 'row', height: 8, borderRadius: radius.full, backgroundColor: colors.primarySoft, overflow: 'hidden' },
  done: { backgroundColor: colors.success },
  way: { backgroundColor: colors.info },
});
