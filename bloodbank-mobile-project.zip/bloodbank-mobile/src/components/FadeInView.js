// بيخلي العنصر "يظهر بنعومة" من تحت لفوق لما الشاشة تفتح. delay = تأخير بالميلي ثانية
// (بنستخدمه عشان العناصر تظهر واحد ورا الثاني).
import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';

export default function FadeInView({ children, delay = 0, style }) {
  const progress = useRef(new Animated.Value(0)).current; // من 0 (مخفي) إلى 1 (ظاهر)

  useEffect(() => {
    Animated.timing(progress, { toValue: 1, duration: 450, delay, useNativeDriver: true }).start();
  }, []);

  return (
    <Animated.View
      style={[style, { opacity: progress, transform: [{ translateY: progress.interpolate({ inputRange: [0, 1], outputRange: [18, 0] }) }] }]}
    >
      {children}
    </Animated.View>
  );
}
