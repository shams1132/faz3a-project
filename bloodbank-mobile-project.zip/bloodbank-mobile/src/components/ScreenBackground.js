// خلفية الشاشات: تدرج وردي ناعم مع دوائر ديكور شفافة، وهي اللي بتعطي الإحساس "الفخم".
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { gradients } from '../theme';

export default function ScreenBackground({ children, style }) {
  return (
    <LinearGradient colors={gradients.soft} style={[styles.fill, style]}>
      {/* دوائر الديكور: pointerEvents none = ما بتمنع الضغط على اللي تحتها */}
      <View pointerEvents="none" style={styles.blobTop} />
      <View pointerEvents="none" style={styles.blobBottom} />
      {children}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  blobTop: { position: 'absolute', top: -80, end: -60, width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(196,18,47,0.07)' },
  blobBottom: { position: 'absolute', bottom: -90, start: -70, width: 240, height: 240, borderRadius: 120, backgroundColor: 'rgba(196,18,47,0.06)' },
});
