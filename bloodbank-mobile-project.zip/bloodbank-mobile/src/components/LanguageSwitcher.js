// زر تبديل اللغة. بعد الضغط التطبيق بيعيد التشغيل عشان الاتجاه يتغير.
import { Pressable, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from './AppText';
import { changeLanguage } from '../i18n';
import { colors, spacing } from '../theme';

export default function LanguageSwitcher() {
  const { t, i18n } = useTranslation();
  // اللغة الجاية: إذا الحالية عربي بتصير إنجليزي، والعكس.
  const nextLanguage = i18n.language === 'ar' ? 'en' : 'ar';

  return (
    <Pressable onPress={() => changeLanguage(nextLanguage)} style={styles.button}>
      <Ionicons name="globe-outline" size={18} color={colors.primary} />
      <AppText variant="caption" color={colors.primary}>{t('common.switchLanguage')}</AppText>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, padding: spacing.sm },
});
