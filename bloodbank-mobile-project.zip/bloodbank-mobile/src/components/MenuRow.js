// صف قائمة (أيقونة + نص + سهم) للمزيد والإعدادات. right = عنصر اختياري بالطرف (مثل Switch).
import { I18nManager, Pressable, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppText from './AppText';
import { colors, spacing } from '../theme';

export default function MenuRow({ icon, label, onPress, right, danger = false, last = false }) {
  const tint = danger ? colors.primary : colors.text;
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={[styles.row, !last && styles.divider]}>
      <View style={[styles.iconBox, danger && { backgroundColor: colors.primarySoft }]}>
        <Ionicons name={icon} size={20} color={colors.primary} />
      </View>
      <AppText variant="bodyBold" color={tint} style={styles.label}>{label}</AppText>
      {right ? right : onPress ? <Ionicons name={I18nManager.isRTL ? 'chevron-back' : 'chevron-forward'} size={18} color={colors.textLight} /> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md - 2 },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  iconBox: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' },
  label: { flex: 1 },
});
