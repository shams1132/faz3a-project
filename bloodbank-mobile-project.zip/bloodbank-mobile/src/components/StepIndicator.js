// مؤشر الخطوات (1 - 2 - 3) بشاشة إنشاء الحساب. current = الخطوة الحالية (تبدأ من 0)
import { StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppText from './AppText';
import { colors, spacing } from '../theme';

export default function StepIndicator({ total = 3, current = 0 }) {
  return (
    <View style={styles.row}>
      {Array.from({ length: total }).map((_, index) => {
        const done = index < current;
        const active = index === current;
        return (
          <View key={index} style={styles.stepWrap}>
            <View style={[styles.circle, (done || active) && styles.circleOn]}>
              {done ? (
                <Ionicons name="checkmark" size={16} color={colors.white} />
              ) : (
                <AppText variant="caption" color={active ? colors.white : colors.textLight}>{index + 1}</AppText>
              )}
            </View>
            {/* الخط بين الدوائر (ما في بعد الأخيرة) */}
            {index < total - 1 ? <View style={[styles.line, done && styles.lineOn]} /> : null}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg },
  stepWrap: { flexDirection: 'row', alignItems: 'center' },
  circle: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  circleOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  line: { width: 40, height: 2, backgroundColor: colors.border },
  lineOn: { backgroundColor: colors.primary },
});
