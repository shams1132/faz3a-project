// شريط صغير بيظهر بس لما USE_MOCK = true، عشان محد يفكر إنه البيانات حقيقية.
// لما نربط الباك اند وتصير USE_MOCK = false بيختفي لحاله.
import { StyleSheet, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import AppText from './AppText';
import { USE_MOCK } from '../config';
import { colors, radius, spacing } from '../theme';

export default function DemoBadge() {
  const { t } = useTranslation();
  if (!USE_MOCK) return null; // بيانات حقيقية: ما في شي نعرضه
  return (
    <View style={styles.box}>
      <AppText variant="caption" color={colors.warning} align="center">{t('common.demoMode')}</AppText>
    </View>
  );
}

const styles = StyleSheet.create({
  box: { backgroundColor: colors.warningSoft, borderRadius: radius.full, paddingVertical: 4, paddingHorizontal: spacing.md, alignSelf: 'center' },
});
