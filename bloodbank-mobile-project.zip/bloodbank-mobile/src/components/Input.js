// حقل إدخال أنيق: أيقونة + عنوان + رسالة خطأ + زر إظهار/إخفاء كلمة المرور.
// أي خاصية ثانية (keyboardType, maxLength...) بتنمرر للحقل مباشرة عن طريق ...props
import { useState } from 'react';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import AppText from './AppText';
import { colors, fonts, fontSize, radius, spacing, textAlign } from '../theme';

export default function Input({ label, icon, error, secureTextEntry, ...props }) {
  const [hidden, setHidden] = useState(Boolean(secureTextEntry)); // هل كلمة المرور مخفية؟
  const [focused, setFocused] = useState(false); // هل الحقل مفتوح للكتابة؟

  return (
    <View style={styles.wrapper}>
      {label ? <AppText variant="caption" style={styles.label}>{label}</AppText> : null}

      <View style={[styles.box, focused && styles.boxFocused, error && styles.boxError]}>
        {icon ? <Ionicons name={icon} size={20} color={focused ? colors.primary : colors.textLight} /> : null}

        <TextInput
          style={styles.input}
          placeholderTextColor={colors.textLight}
          autoCapitalize="none"
          secureTextEntry={hidden}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          {...props}
        />

        {/* زر العين: بس لحقول كلمة المرور */}
        {secureTextEntry ? (
          <Pressable onPress={() => setHidden((h) => !h)} hitSlop={10}>
            <Ionicons name={hidden ? 'eye-off-outline' : 'eye-outline'} size={20} color={colors.textLight} />
          </Pressable>
        ) : null}
      </View>

      {error ? <AppText variant="caption" color={colors.primary} style={styles.error}>{error}</AppText> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: spacing.md },
  label: { marginBottom: spacing.xs },
  box: {
    flexDirection: 'row', // بينقلب تلقائياً بالعربي (الأيقونة بتصير عاليمين)
    alignItems: 'center',
    gap: spacing.sm,
    minHeight: 54,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1.5,
    borderColor: colors.border,
    backgroundColor: colors.white,
  },
  boxFocused: { borderColor: colors.primary },
  boxError: { borderColor: colors.primary, backgroundColor: '#FFF5F6' },
  input: { flex: 1, fontFamily: fonts.regular, fontSize: fontSize.md, color: colors.text, textAlign, paddingVertical: 10 },
  error: { marginTop: spacing.xs },
});
