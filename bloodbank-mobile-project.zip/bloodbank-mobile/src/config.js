// إعدادات المشروع كلها بمكان واحد. إذا بدك تغيّري شي، غيّريه هون بس.

// true = بيانات وهمية (mock). خليها false لما نربط مع الباك اند.
export const USE_MOCK = true;

// رابط الباك اند. لازم يكون عنوان الكمبيوتر على الشبكة، مش localhost
// (لأن التلفون ما بيفهم localhost). غيّريه حسب اللي بيعطيكي إياه الباك اند.
export const API_BASE_URL = 'http://192.168.1.10:3000/api';

// رقم المستشفى لزر الاتصال. رقم تجريبي، بدّليه بالرقم الحقيقي.
export const HOSPITAL_PHONE = '042000000';

// عدد الأيام بين تبرع وتبرع. تأكدوا من المستشفى عن الرقم الصحيح.
export const ELIGIBILITY_DAYS = 56;

// كل تبرع بيساعد حتى 3 أشخاص (معلومة طبية شائعة). بنستخدمها لعدّاد "أرواح أنقذتها".
export const LIVES_PER_DONATION = 3;

export const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

// المدن (أكواد، والأسماء بملفات الترجمة تحت cities)
export const CITIES = ['jenin', 'qabatiya', 'yabad', 'arraba', 'tubas', 'nablus', 'tulkarm'];

// أكواد ثابتة متفق عليها مع الباك اند
export const REQUEST_STATUS = { PENDING: 'PENDING', ON_THE_WAY: 'ON_THE_WAY', DONE: 'DONE' };
export const DONOR_RESPONSE = { ON_THE_WAY: 'ON_THE_WAY', DECLINED: 'DECLINED' };
export const URGENCY = { URGENT: 'URGENT', NORMAL: 'NORMAL' };
