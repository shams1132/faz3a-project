// الـ Context: مكان مشترك بنخزن فيه "مين المستخدم المسجّل" وبتقدر أي شاشة تقرأه
// عن طريق useAuth()، بدون ما نمرره من شاشة لشاشة.
import { createContext, useContext, useEffect, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { login, register } from '../services/authService';
import { TOKEN_KEY } from '../services/api';

// أسماء المفاتيح اللي بنحفظ فيها البيانات بالتخزين الآمن (SecureStore).
const USER_KEY = 'auth_user';
// بنعمل الـ Context (الصندوق المشترك).
const AuthContext = createContext(null);

// AuthProvider: مكون بيلف التطبيق وبيوفر بيانات المستخدم لكل الشاشات.
export function AuthProvider({ children }) {
  // user: بيانات المستخدم المسجّل. null يعني ما في حدا مسجّل دخول.
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // بنفحص إذا في مستخدم محفوظ

  // أول ما يفتح التطبيق: إذا في مستخدم محفوظ بنرجّعه (ما بنطلب تسجيل دخول كل مرة)
  useEffect(() => {
    async function restoreUser() {
      try {
        const saved = await SecureStore.getItemAsync(USER_KEY);
        if (saved) setUser(JSON.parse(saved));
      } finally {
        setLoading(false);
      }
    }
    restoreUser();
  }, []);

  // بنحفظ التوكن والمستخدم بعد الدخول أو التسجيل
  async function saveSession({ token, user: loggedUser }) {
    await SecureStore.setItemAsync(TOKEN_KEY, token);
    await SecureStore.setItemAsync(USER_KEY, JSON.stringify(loggedUser));
    setUser(loggedUser);
  }

  // signIn و signUp: بينادوا الخدمة (الباك اند أو الوهمية)، وبعدين بيحفظوا الجلسة.
  const signIn = async (phone, password) => saveSession(await login(phone, password));
  const signUp = async (data) => saveSession(await register(data));

  // تسجيل الخروج: بنمسح البيانات المحفوظة ونفرّغ المستخدم،
  // فالتنقل بيرجع لشاشة الدخول لحاله.
  async function signOut() {
    await SecureStore.deleteItemAsync(TOKEN_KEY);
    await SecureStore.deleteItemAsync(USER_KEY);
    setUser(null);
  }

  return (
    // كل اللي بنحطه بـ value بتقدر أي شاشة تقراه عن طريق useAuth().
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

// اختصار: const { user } = useAuth();
export const useAuth = () => useContext(AuthContext);
