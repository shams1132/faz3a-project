// شاشة الترحيب: قطرة كبيرة، شعار التطبيق، وزر "ابدأ الآن".
import { Pressable, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native-safe-area-context';
import AppText from '../components/AppText';
import BloodDrop from '../components/BloodDrop';
import Button from '../components/Button';
import FadeInView from '../components/FadeInView';
import LanguageSwitcher from '../components/LanguageSwitcher';
import { colors, gradients, spacing } from '../theme';

export default function WelcomeScreen({ navigation }) {
  const { t } = useTranslation();

  return (
    // التدرج: من وردي فاتح (فوق) إلى أحمر داكن (تحت)، locations = وين بيبدأ كل لون
    <LinearGradient colors={gradients.welcome} locations={[0, 0.42, 0.75, 1]} style={styles.fill}>
      <SafeAreaView style={styles.fill}>
        <View style={styles.topRow}>
          <LanguageSwitcher />
        </View>

        <FadeInView style={styles.hero}>
          <BloodDrop size={150} animated />
          <AppText variant="display" color={colors.primaryDark} style={styles.title}>{t('welcome.title')}</AppText>
          <AppText variant="body" color={colors.textLight}>{t('welcome.subtitle')}</AppText>
        </FadeInView>

        <FadeInView delay={250} style={styles.bottom}>
          <Button title={t('welcome.start')} variant="light" onPress={() => navigation.navigate('Login')} />
          <Pressable onPress={() => navigation.navigate('Login')} style={styles.loginRow}>
            <AppText variant="caption" color="rgba(255,255,255,0.8)">{t('welcome.haveAccount')}</AppText>
            <AppText variant="caption" color={colors.white} style={styles.loginLink}>{t('welcome.login')}</AppText>
          </Pressable>
        </FadeInView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  topRow: { flexDirection: 'row', justifyContent: 'flex-end', paddingHorizontal: spacing.md },
  hero: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  title: { marginTop: spacing.lg, textAlign: 'center' },
  bottom: { paddingHorizontal: spacing.lg, paddingBottom: spacing.lg, gap: spacing.md },
  loginRow: { flexDirection: 'row', justifyContent: 'center', gap: spacing.xs },
  loginLink: { textDecorationLine: 'underline' },
});
