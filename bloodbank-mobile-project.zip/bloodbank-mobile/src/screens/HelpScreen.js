// الدعم والمساعدة: أسئلة شائعة (تنفتح وتنسكر) + زر اتصال حقيقي بالمستشفى.
// بدل محادثة بردود جاهزة (كانت شكلها بس)، هاي معلومات ثابتة وصحيحة وزر اتصال بيشتغل فعلاً.
import { useState } from 'react';
import { Linking, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Button from '../components/Button';
import Card from '../components/Card';
import ScreenBackground from '../components/ScreenBackground';
import { HOSPITAL_PHONE } from '../config';
import { colors, spacing } from '../theme';

const QUESTIONS = ['q1', 'q2', 'q3', 'q4']; // مفاتيح الأسئلة بملفات الترجمة (help.q1 ...)

export default function HelpScreen() {
  const { t } = useTranslation();
  const [openKey, setOpenKey] = useState(null); // السؤال المفتوح حالياً (null = ولا واحد)

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.content}>
        <Card>
          {QUESTIONS.map((key, index) => {
            const open = openKey === key;
            return (
              <View key={key} style={index < QUESTIONS.length - 1 && styles.divider}>
                {/* ضغطة على السؤال: بتفتحه إذا مسكّر، وبتسكره إذا مفتوح */}
                <Pressable onPress={() => setOpenKey(open ? null : key)} style={styles.question}>
                  <AppText variant="bodyBold" style={styles.questionText}>{t(`help.${key}`)}</AppText>
                  <Ionicons name={open ? 'chevron-up' : 'chevron-down'} size={18} color={colors.primary} />
                </Pressable>
                {open ? <AppText variant="body" color={colors.textLight} style={styles.answer}>{t(`help.a${index + 1}`)}</AppText> : null}
              </View>
            );
          })}
        </Card>

        <AppText variant="caption" align="center">{t('help.contact')}</AppText>
        <Button title={t('hospital.call')} icon="call-outline" onPress={() => Linking.openURL(`tel:${HOSPITAL_PHONE}`)} />
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.md, gap: spacing.md },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  question: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.md - 2 },
  questionText: { flex: 1 },
  answer: { paddingBottom: spacing.md },
});
