// إنشاء حساب متبرع جديد على 3 خطوات: بيانات شخصية ← صحة وفصيلة ← أمان الحساب.
// فكرة الخطوات: متغير step بيحدد أي جزء من الفورم نعرض، وكل خطوة إلها تحقق خاص فيها.
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import BloodTypePicker from '../components/BloodTypePicker';
import Button from '../components/Button';
import Card from '../components/Card';
import Input from '../components/Input';
import ScreenBackground from '../components/ScreenBackground';
import StepIndicator from '../components/StepIndicator';
import { useAuth } from '../context/AuthContext';
import { CITIES } from '../config';
import { isValidPhone } from '../utils/validation';
import { colors, radius, spacing } from '../theme';

export default function RegisterScreen({ navigation }) {
  const { t } = useTranslation();
  const { signUp } = useAuth();

  const [step, setStep] = useState(0); // الخطوة الحالية (0 و 1 و 2)
  const [form, setForm] = useState({ name: '', phone: '', city: '', bloodType: '', confirmed: false, password: '', confirmPassword: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  // بتغير حقل واحد بالفورم بدون ما تمسح الباقي
  const setField = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  // تحقق خاص بكل خطوة. بترجع true إذا كل شي تمام.
  function validateStep() {
    const e = {};
    if (step === 0) {
      if (form.name.trim().length < 3) e.name = t('validation.nameShort');
      if (!isValidPhone(form.phone)) e.phone = t('validation.phoneInvalid');
      if (!form.city) e.city = t('validation.cityRequired');
    } else if (step === 1) {
      if (!form.bloodType) e.bloodType = t('validation.bloodRequired');
      if (!form.confirmed) e.confirmed = t('validation.termsRequired');
    } else {
      if (form.password.length < 6) e.password = t('validation.passwordShort');
      if (form.password !== form.confirmPassword) e.confirmPassword = t('validation.passwordMismatch');
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleNext() {
    if (!validateStep()) return;
    if (step < 2) {
      setStep(step + 1); // الخطوة الجاية
      return;
    }
    // آخر خطوة: بنبعت كل البيانات للسيرفر
    setServerError('');
    setLoading(true);
    try {
      await signUp({ name: form.name.trim(), phone: form.phone, password: form.password, bloodType: form.bloodType, city: form.city });
    } catch {
      setServerError(t('common.errorGeneric'));
    } finally {
      setLoading(false);
    }
  }

  // زر الرجوع: إذا بالخطوة الأولى بنرجع للدخول، وإلا للخطوة اللي قبلها
  const handleBack = () => (step === 0 ? navigation.goBack() : setStep(step - 1));

  return (
    <ScreenBackground>
      <SafeAreaView style={styles.fill}>
        <KeyboardAvoidingView style={styles.fill} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
            <AppText variant="title" align="center">{t('register.title')}</AppText>
            <AppText variant="caption" align="center" style={styles.stepTitle}>{t(`register.step${step + 1}`)}</AppText>
            <StepIndicator total={3} current={step} />

            <Card>
              {/* الخطوة 1: بيانات شخصية */}
              {step === 0 && (
                <View>
                  <Input icon="person-outline" label={t('register.fullName')} value={form.name} onChangeText={(v) => setField('name', v)} autoCapitalize="words" error={errors.name} />
                  <Input icon="phone-portrait-outline" label={t('auth.phone')} value={form.phone} onChangeText={(v) => setField('phone', v)} keyboardType="phone-pad" maxLength={10} error={errors.phone} />
                  <AppText variant="caption" style={styles.label}>{t('register.city')}</AppText>
                  {/* المدن: أزرار بنختار منها وحدة */}
                  <View style={styles.cities}>
                    {CITIES.map((code) => (
                      <Pressable key={code} onPress={() => setField('city', code)} style={[styles.cityChip, form.city === code && styles.cityChipOn]}>
                        <AppText variant="caption" color={form.city === code ? colors.white : colors.text}>{t(`cities.${code}`)}</AppText>
                      </Pressable>
                    ))}
                  </View>
                  {errors.city ? <AppText variant="caption" color={colors.primary}>{errors.city}</AppText> : null}
                </View>
              )}

              {/* الخطوة 2: فصيلة الدم وتأكيد الشروط الصحية */}
              {step === 1 && (
                <View>
                  <AppText variant="caption" style={styles.label}>{t('register.bloodType')}</AppText>
                  <BloodTypePicker value={form.bloodType} onChange={(v) => setField('bloodType', v)} error={errors.bloodType} />
                  <Pressable onPress={() => setField('confirmed', !form.confirmed)} style={styles.checkRow}>
                    <View style={[styles.checkbox, form.confirmed && styles.checkboxOn]}>
                      {form.confirmed ? <Ionicons name="checkmark" size={16} color={colors.white} /> : null}
                    </View>
                    <AppText variant="caption" color={colors.text} style={styles.checkText}>{t('register.weightConfirm')}</AppText>
                  </Pressable>
                  {errors.confirmed ? <AppText variant="caption" color={colors.primary}>{errors.confirmed}</AppText> : null}
                </View>
              )}

              {/* الخطوة 3: كلمة المرور */}
              {step === 2 && (
                <View>
                  <Input icon="lock-closed-outline" label={t('auth.password')} value={form.password} onChangeText={(v) => setField('password', v)} secureTextEntry error={errors.password} />
                  <Input icon="lock-closed-outline" label={t('register.confirmPassword')} value={form.confirmPassword} onChangeText={(v) => setField('confirmPassword', v)} secureTextEntry error={errors.confirmPassword} />
                  {serverError ? <AppText variant="caption" color={colors.primary} align="center">{serverError}</AppText> : null}
                </View>
              )}
            </Card>

            <View style={styles.buttons}>
              <Button title={step === 2 ? t('register.finish') : t('register.next')} onPress={handleNext} loading={loading} />
              <Button title={t('register.previous')} variant="outline" onPress={handleBack} />
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  container: { padding: spacing.lg },
  stepTitle: { marginBottom: spacing.md },
  label: { marginBottom: spacing.sm },
  cities: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  cityChip: { paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.full, backgroundColor: colors.bg, borderWidth: 1.5, borderColor: colors.border },
  cityChipOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  checkRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.lg },
  checkbox: { width: 24, height: 24, borderRadius: 8, borderWidth: 1.5, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
  checkboxOn: { backgroundColor: colors.primary, borderColor: colors.primary },
  checkText: { flex: 1 },
  buttons: { gap: spacing.sm, marginTop: spacing.lg },
});
