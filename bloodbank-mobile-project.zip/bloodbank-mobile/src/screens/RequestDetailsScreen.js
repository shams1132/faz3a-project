// تفاصيل الطلب: هيدر بالفصيلة + حالة الطلب + الأزرار (أنا في طريقي / اعتذار / اتصال).
// بيانات الطلب بتوصل من الشاشة اللي فتحتها (route.params.request)، فما بنحتاج استدعاء إضافي للسيرفر.
import { useState } from 'react';
import { Alert, Linking, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Button from '../components/Button';
import Card from '../components/Card';
import FadeInView from '../components/FadeInView';
import ProgressBar from '../components/ProgressBar';
import ScreenBackground from '../components/ScreenBackground';
import StatusBadge from '../components/StatusBadge';
import { respondToRequest } from '../services/requestsService';
import { DONOR_RESPONSE, HOSPITAL_PHONE, REQUEST_STATUS } from '../config';
import { formatDate } from '../utils/dateHelpers';
import { colors, fonts, gradients, radius, shadow, spacing } from '../theme';

// مربع صغير: رقم + عنوانه (مطلوب / في الطريق / تم التبرع)
function Stat({ label, value, color }) {
  return (
    <View style={styles.stat}>
      <AppText variant="title" color={color} style={{ fontFamily: fonts.black }}>{value}</AppText>
      <AppText variant="caption">{label}</AppText>
    </View>
  );
}

export default function RequestDetailsScreen({ route, navigation }) {
  const { t, i18n } = useTranslation();

  // request: بيانات الطلب (بنبدأ بالنسخة اللي وصلت، وبنحدثها بعد ما المتبرع يرد)
  const [request, setRequest] = useState(route.params.request);
  const [sending, setSending] = useState(false); // عم نبعت الرد للسيرفر

  // Alert.alert: نافذة منبثقة (عنوان، رسالة، أزرار) بنسأل فيها "متأكد؟"
  function confirmResponse(donorResponse) {
    const message = donorResponse === DONOR_RESPONSE.ON_THE_WAY ? t('details.confirmOnMyWay') : t('details.confirmDecline');
    Alert.alert(t('details.confirmTitle'), message, [
      { text: t('common.cancel'), style: 'cancel' },
      { text: t('common.confirm'), onPress: () => sendResponse(donorResponse) },
    ]);
  }

  // بتبعت رد المتبرع للسيرفر. إذا نجحت بنحدّث الأرقام عندنا، وإذا "في طريقي" بننتقل لشاشة الشكر.
  async function sendResponse(donorResponse) {
    setSending(true);
    try {
      await respondToRequest(request.id, donorResponse);
      const onTheWay = donorResponse === DONOR_RESPONSE.ON_THE_WAY;
      setRequest((prev) => ({ ...prev, myResponse: donorResponse, unitsOnTheWay: prev.unitsOnTheWay + (onTheWay ? 1 : 0) }));
      if (onTheWay) navigation.replace('Success');
    } catch {
      Alert.alert(t('common.errorGeneric')); // فشل الإرسال: ما غيرنا شي بالشاشة
    } finally {
      setSending(false);
    }
  }

  // alreadyResponded: هل المتبرع رد؟ canRespond: هل نعرض الأزرار؟ (لأ إذا رد أو الطلب خلص)
  const alreadyResponded = Boolean(request.myResponse);
  const canRespond = !alreadyResponded && request.status !== REQUEST_STATUS.DONE;

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* الهيدر الأحمر: الفصيلة الكبيرة */}
        <FadeInView>
          <LinearGradient colors={gradients.primary} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.hero, shadow.button]}>
            <View style={styles.bigType}>
              <AppText color={colors.primary} style={styles.bigTypeText}>{request.bloodType}</AppText>
            </View>
            <View style={styles.heroInfo}>
              <AppText variant="heading" color={colors.white}>{t('hospital.name')}</AppText>
              <AppText variant="caption" color="rgba(255,255,255,0.8)">
                {t('details.createdAt')}: {formatDate(request.createdAt, i18n.language)}
              </AppText>
              <View style={styles.badges}>
                <StatusBadge kind="urgency" value={request.urgency} />
                <StatusBadge kind="status" value={request.status} />
              </View>
            </View>
          </LinearGradient>
        </FadeInView>

        {/* حالة الطلب */}
        <FadeInView delay={120}>
          <Card style={styles.gap}>
            <View style={styles.statsRow}>
              <Stat label={t('details.needed')} value={request.unitsNeeded} color={colors.text} />
              <Stat label={t('details.onTheWay')} value={request.unitsOnTheWay} color={colors.info} />
              <Stat label={t('details.done')} value={request.unitsDone} color={colors.success} />
            </View>
            <ProgressBar done={request.unitsDone} onTheWay={request.unitsOnTheWay} total={request.unitsNeeded} />
            <AppText variant="caption" align="center">{t('details.progress', { done: request.unitsDone, total: request.unitsNeeded })}</AppText>
          </Card>
        </FadeInView>

        {/* الملاحظات: بتظهر بس إذا موجودة */}
        {request.notes ? (
          <FadeInView delay={200}>
            <Card style={styles.noteCard}>
              <Ionicons name="document-text-outline" size={22} color={colors.primary} />
              <View style={styles.noteText}>
                <AppText variant="caption">{t('details.notes')}</AppText>
                <AppText variant="bodyBold">{request.notes}</AppText>
              </View>
            </Card>
          </FadeInView>
        ) : null}

        {/* الأزرار */}
        <FadeInView delay={280} style={styles.actions}>
          {canRespond ? (
            <>
              <Button title={t('details.onMyWay')} icon="heart" onPress={() => confirmResponse(DONOR_RESPONSE.ON_THE_WAY)} loading={sending} />
              <Button title={t('details.decline')} variant="outline" onPress={() => confirmResponse(DONOR_RESPONSE.DECLINED)} disabled={sending} />
            </>
          ) : null}
          {alreadyResponded ? (
            <AppText variant="bodyBold" color={colors.success} align="center">
              {request.myResponse === DONOR_RESPONSE.ON_THE_WAY ? t('details.respondedOnWay') : t('details.respondedDeclined')}
            </AppText>
          ) : null}
          {/* زر الاتصال بالمستشفى: Linking.openURL بيفتح تطبيق الاتصال بالجهاز */}
          <Button title={t('hospital.call')} icon="call-outline" variant="outline" onPress={() => Linking.openURL(`tel:${HOSPITAL_PHONE}`)} />
        </FadeInView>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.md, gap: spacing.md },
  hero: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, borderRadius: radius.xl, padding: spacing.lg },
  bigType: { width: 84, height: 84, borderRadius: 42, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' },
  bigTypeText: { fontFamily: fonts.black, fontSize: 28, lineHeight: 40 },
  heroInfo: { flex: 1, gap: 4 },
  badges: { flexDirection: 'row', gap: spacing.sm, marginTop: 2 },
  gap: { gap: spacing.md },
  statsRow: { flexDirection: 'row' },
  stat: { flex: 1, alignItems: 'center' },
  noteCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  noteText: { flex: 1 },
  actions: { gap: spacing.sm, marginTop: spacing.sm },
});
