// شاشة تسجيل الدخول: شعار + تبويب (دخول / إنشاء حساب) + حقول + زر.
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import BloodDrop from '../components/BloodDrop';
import Button from '../components/Button';
import FadeInView from '../components/FadeInView';
import Input from '../components/Input';
import LanguageSwitcher from '../components/LanguageSwitcher';
import ScreenBackground from '../components/ScreenBackground';
import { useAuth } from '../context/AuthContext';
import { isAuthError, isValidPhone } from '../utils/validation';
import { colors, radius, shadow, spacing } from '../theme';

export default function LoginScreen({ navigation }) {
  const { t } = useTranslation(); // t: دالة الترجمة، t('auth.phone') بترجع النص حسب اللغة
  const { signIn } = useAuth(); // signIn: دالة تسجيل الدخول من AuthContext

  // state: القيم اللي بتتغير وبتخلي الشاشة تتحدث
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({}); // رسالة خطأ تحت كل حقل
  const [serverError, setServerError] = useState(''); // خطأ جاي من السيرفر
  const [loading, setLoading] = useState(false); // عم نستنى الرد

  // بنتحقق من المدخلات قبل ما نبعتها للسيرفر
  function validate() {
    const newErrors = {};
    if (!isValidPhone(phone)) newErrors.phone = t('validation.phoneInvalid');
    if (password.length < 6) newErrors.password = t('validation.passwordShort');
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  // بتشتغل لما نضغط زر الدخول: تحقق ← إرسال للسيرفر ← معالجة الخطأ
  async function handleLogin() {
    setServerError('');
    if (!validate()) return;
    setLoading(true);
    try {
      await signIn(phone, password);
      // ما بنحتاج navigation: لما user يتعبّى، التنقل بيبدّل الشاشات لحاله
    } catch (err) {
      setServerError(isAuthError(err) ? t('auth.invalidCredentials') : t('common.errorGeneric'));
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenBackground>
      <SafeAreaView style={styles.fill}>
        {/* KeyboardAvoidingView: بيرفع المحتوى لما الكيبورد يفتح */}
        <KeyboardAvoidingView style={styles.fill} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
            <View style={styles.topRow}>
              <LanguageSwitcher />
            </View>

            <FadeInView style={styles.logoBox}>
              <BloodDrop size={72} />
              <AppText variant="title" color={colors.primaryDark}>{t('app.name')}</AppText>
              <AppText variant="caption">{t('app.slogan')}</AppText>
            </FadeInView>

            {/* تبويب: دخول (مفعّل) / إنشاء حساب (بينقلنا لشاشة التسجيل) */}
            <FadeInView delay={120} style={styles.tabs}>
              <Pressable style={[styles.tab, styles.tabActive]}>
                <AppText variant="bodyBold" color={colors.white}>{t('auth.tabLogin')}</AppText>
              </Pressable>
              <Pressable style={styles.tab} onPress={() => navigation.navigate('Register')}>
                <AppText variant="bodyBold" color={colors.textLight}>{t('auth.tabRegister')}</AppText>
              </Pressable>
            </FadeInView>

            <FadeInView delay={220}>
              <Input
                icon="phone-portrait-outline"
                placeholder={t('auth.phone')}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
                maxLength={10}
                error={errors.phone}
              />
              <Input
                icon="lock-closed-outline"
                placeholder={t('auth.password')}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                error={errors.password}
              />

              {serverError ? <AppText variant="caption" color={colors.primary} align="center" style={styles.serverError}>{serverError}</AppText> : null}

              <Button title={t('auth.loginButton')} onPress={handleLogin} loading={loading} />

            </FadeInView>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  container: { padding: spacing.lg },
  topRow: { flexDirection: 'row', justifyContent: 'flex-end' },
  logoBox: { alignItems: 'center', marginTop: spacing.sm, marginBottom: spacing.lg, gap: 2 },
  tabs: { flexDirection: 'row', backgroundColor: colors.white, borderRadius: radius.full, padding: 4, marginBottom: spacing.lg, ...shadow.card },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: radius.full },
  tabActive: { backgroundColor: colors.primary },
  serverError: { marginBottom: spacing.md },
});
