// سجل التبرعات السابقة.
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, StyleSheet, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import BloodBadge from '../components/BloodBadge';
import Card from '../components/Card';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import ScreenBackground from '../components/ScreenBackground';
import { getMyDonations } from '../services/donationsService';
import { formatDate } from '../utils/dateHelpers';
import { colors, spacing } from '../theme';

export default function DonationHistoryScreen() {
  const { t, i18n } = useTranslation();
  const [donations, setDonations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  async function loadDonations() {
    try {
      setError(false);
      setDonations(await getMyDonations());
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }

  useFocusEffect(useCallback(() => { loadDonations(); }, []));

  if (loading) return <ScreenBackground><View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View></ScreenBackground>;
  if (error) return <ScreenBackground><ErrorState onRetry={loadDonations} /></ScreenBackground>;

  return (
    <ScreenBackground>
      <FlatList
        contentContainerStyle={styles.list}
        data={donations}
        keyExtractor={(item) => String(item.id)}
        // كارد لكل تبرع: الفصيلة، المستشفى، التاريخ، عدد الوحدات
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <BloodBadge type={item.bloodType} size={46} />
            <View style={styles.info}>
              <AppText variant="bodyBold">{t('hospital.name')}</AppText>
              <AppText variant="caption">{formatDate(item.date, i18n.language)}</AppText>
            </View>
            <AppText variant="caption" color={colors.primary}>{t('common.units', { count: item.units })}</AppText>
          </Card>
        )}
        ListEmptyComponent={<EmptyState icon="heart-outline" message={t('history.empty')} />}
      />
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  list: { padding: spacing.md, gap: spacing.md },
  card: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  info: { flex: 1 },
});
