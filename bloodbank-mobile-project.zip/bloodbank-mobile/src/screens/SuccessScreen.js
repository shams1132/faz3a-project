// شاشة النجاح بعد "أنا في طريقي": قلب نابض مع بالونات ألوان ونص شكر.
import { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Button from '../components/Button';
import FadeInView from '../components/FadeInView';
import ScreenBackground from '../components/ScreenBackground';
import { colors, spacing } from '../theme';

// نقاط الاحتفال حول القلب: (إزاحة x, إزاحة y, اللون)
const CONFETTI = [
  [-70, -60, '#F5B301'], [70, -50, '#2F6FDE'], [-90, 0, '#C4122F'], [90, 10, '#F5B301'],
  [-60, 60, '#2F6FDE'], [65, 65, '#C4122F'], [0, -95, '#1E9E5A'], [0, 95, '#F5B301'],
];

export default function SuccessScreen({ navigation }) {
  const { t } = useTranslation();
  const pop = useRef(new Animated.Value(0)).current; // 0 → 1 : حركة ظهور القلب

  useEffect(() => {
    Animated.spring(pop, { toValue: 1, friction: 4, useNativeDriver: true }).start();
  }, []);

  // reset: بنمسح تاريخ التنقل ونرجع للرئيسية (فما يرجع المستخدم لهاي الشاشة بزر الرجوع)
  const goHome = () => navigation.reset({ index: 0, routes: [{ name: 'Main' }] });

  return (
    <ScreenBackground>
      <SafeAreaView style={styles.fill}>
        <View style={styles.center}>
          <View style={styles.heartBox}>
            {CONFETTI.map(([x, y, color], i) => (
              <Animated.View
                key={i}
                style={[styles.dot, { backgroundColor: color, transform: [{ translateX: x }, { translateY: y }, { scale: pop }] }]}
              />
            ))}
            <Animated.View style={[styles.heartCircle, { transform: [{ scale: pop }] }]}>
              <Ionicons name="heart" size={64} color={colors.white} />
            </Animated.View>
          </View>

          <FadeInView delay={300} style={styles.texts}>
            <AppText variant="display" align="center">{t('success.title')}</AppText>
            <AppText variant="body" color={colors.textLight} align="center">{t('success.subtitle')}</AppText>
          </FadeInView>
        </View>

        <View style={styles.bottom}>
          <Button title={t('success.home')} onPress={goHome} />
        </View>
      </SafeAreaView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  fill: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: spacing.lg },
  heartBox: { width: 220, height: 220, alignItems: 'center', justifyContent: 'center' },
  heartCircle: { width: 120, height: 120, borderRadius: 60, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', shadowColor: colors.primary, shadowOpacity: 0.4, shadowRadius: 20, shadowOffset: { width: 0, height: 10 }, elevation: 10 },
  dot: { position: 'absolute', width: 12, height: 12, borderRadius: 6 },
  texts: { gap: spacing.sm, marginTop: spacing.md },
  bottom: { padding: spacing.lg },
});
