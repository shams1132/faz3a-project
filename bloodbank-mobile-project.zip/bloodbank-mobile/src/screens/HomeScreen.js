// الرئيسية: ترحيب + بانر + إحصائياتي + الطلبات العاجلة.
// مبدأ مهم: أي رقم بنعرضه لازم يكون حقيقي. إذا البيانات مش متوفرة، بنخفي العنصر بدل ما نعرض رقم مزيف.
import { useCallback, useState } from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Avatar from '../components/Avatar';
import BloodDrop from '../components/BloodDrop';
import Button from '../components/Button';
import Card from '../components/Card';
import DemoBadge from '../components/DemoBadge';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import FadeInView from '../components/FadeInView';
import RequestCard from '../components/RequestCard';
import ScreenBackground from '../components/ScreenBackground';
import SectionHeader from '../components/SectionHeader';
import { useAuth } from '../context/AuthContext';
import { getCompatibleRequests } from '../services/requestsService';
import { getMyDonations } from '../services/donationsService';
import { getNextEligibleDate } from '../utils/dateHelpers';
import { LIVES_PER_DONATION } from '../config';
import { colors, fonts, gradients, radius, shadow, spacing } from '../theme';

// مربع إحصائية صغير (رقم + عنوان)
function Stat({ icon, value, label }) {
  return (
    <Card style={styles.stat}>
      <Ionicons name={icon} size={20} color={colors.primary} />
      <AppText variant="heading" style={styles.statValue}>{value}</AppText>
      <AppText variant="caption" align="center" style={styles.statLabel}>{label}</AppText>
    </Card>
  );
}

export default function HomeScreen({ navigation }) {
  const { t } = useTranslation();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  // requests: الطلبات. donations: سجل التبرعات (null = السيرفر ما وفّره، فبنخفي الإحصائيات)
  const [requests, setRequests] = useState([]);
  const [donations, setDonations] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(false);

  async function loadData() {
    try {
      setError(false);
      // الطلبات ضرورية (إذا فشلت بنعرض خطأ). السجل اختياري (إذا فشل بنخفي إحصائياته بس).
      const [requestsResult, donationsResult] = await Promise.all([
        getCompatibleRequests(user.bloodType),
        getMyDonations().catch(() => null),
      ]);
      setRequests(requestsResult);
      setDonations(donationsResult);
    } catch {
      setError(true);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  // بتشتغل كل ما ترجعي لهاي الشاشة، فالأرقام بتتحدث بعد ما ترد على طلب
  useFocusEffect(useCallback(() => { loadData(); }, [user.bloodType]));

  if (loading) {
    return <ScreenBackground><View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View></ScreenBackground>;
  }
  if (error) return <ScreenBackground><ErrorState onRetry={loadData} /></ScreenBackground>;

  const urgent = requests.filter((r) => r.urgency === 'URGENT' && r.status !== 'DONE').slice(0, 2);

  // الإحصائيات: كل وحدة بتظهر بس إذا بياناتها متوفرة فعلاً
  const stats = [];
  if (donations) {
    stats.push({ icon: 'water', value: donations.length, label: t('home.statDonations') });
    stats.push({ icon: 'heart', value: donations.length * LIVES_PER_DONATION, label: t('home.statLives') });
  }
  // lastDonationDate === undefined يعني السيرفر ما بعت هاد الحقل، فما بنعرف الموعد
  if (user.lastDonationDate !== undefined) {
    const nextDate = getNextEligibleDate(user.lastDonationDate);
    const daysLeft = nextDate ? Math.ceil((nextDate - new Date()) / 86400000) : 0;
    stats.push({ icon: 'calendar', value: daysLeft <= 0 ? t('home.eligibleNow') : t('home.daysLeft', { count: daysLeft }), label: t('home.statNext') });
  }

  return (
    <ScreenBackground>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: insets.top + spacing.sm }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadData(); }} tintColor={colors.primary} />}
      >
        {/* الهيدر: صورة + ترحيب */}
        <FadeInView style={styles.header}>
          <Avatar name={user.name} size={46} />
          <View>
            <AppText variant="bodyBold">{t('home.greeting', { name: user.name.split(' ')[0] })}</AppText>
            <AppText variant="caption">{t('home.motto')}</AppText>
          </View>
        </FadeInView>

        <DemoBadge />

        {/* البانر الأحمر */}
        <FadeInView delay={100}>
          <LinearGradient colors={gradients.primary} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={[styles.banner, shadow.button]}>
            <View style={styles.bannerText}>
              <AppText variant="heading" color={colors.white} style={styles.bannerTitle}>{t('home.bannerTitle')}</AppText>
              <Button title={t('home.bannerButton')} variant="light" onPress={() => navigation.navigate('Requests')} style={styles.bannerButton} />
            </View>
            <BloodDrop size={84} animated />
          </LinearGradient>
        </FadeInView>

        {stats.length > 0 ? (
          <FadeInView delay={180} style={styles.statsRow}>
            {stats.map((s) => <Stat key={s.label} icon={s.icon} value={s.value} label={s.label} />)}
          </FadeInView>
        ) : null}

        {/* الطلبات العاجلة */}
        <FadeInView delay={260} style={styles.section}>
          <SectionHeader title={t('home.urgentTitle')} actionLabel={t('common.viewAll')} onAction={() => navigation.navigate('Requests')} />
          {urgent.length === 0 ? (
            <EmptyState icon="checkmark-circle-outline" message={t('home.noUrgent')} />
          ) : (
            urgent.map((request) => (
              <RequestCard key={request.id} request={request} onPress={() => navigation.navigate('RequestDetails', { request })} />
            ))
          )}
        </FadeInView>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  content: { paddingHorizontal: spacing.md, paddingBottom: spacing.xl, gap: spacing.md },
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  banner: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderRadius: radius.xl, padding: spacing.lg, overflow: 'hidden' },
  bannerText: { flex: 1, gap: spacing.md, alignItems: 'flex-start' },
  bannerTitle: { fontFamily: fonts.black },
  bannerButton: { alignSelf: 'flex-start' },
  statsRow: { flexDirection: 'row', gap: spacing.sm },
  stat: { flex: 1, alignItems: 'center', paddingHorizontal: spacing.sm },
  statValue: { marginTop: 4 },
  statLabel: { fontSize: 11, lineHeight: 16 },
  section: { gap: spacing.xs },
});
