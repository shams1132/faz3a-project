// معلوماتي الشخصية: عرض بيانات المتبرع وموعد التبرع القادم.
import { ScrollView, StyleSheet, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Avatar from '../components/Avatar';
import Card from '../components/Card';
import FadeInView from '../components/FadeInView';
import ScreenBackground from '../components/ScreenBackground';
import { useAuth } from '../context/AuthContext';
import { formatDate, getNextEligibleDate } from '../utils/dateHelpers';
import { colors, spacing } from '../theme';

// صف: أيقونة + عنوان صغير + قيمة
function InfoRow({ icon, label, value, highlight, last }) {
  return (
    <View style={[styles.row, !last && styles.divider]}>
      <View style={styles.iconBox}><Ionicons name={icon} size={18} color={colors.primary} /></View>
      <View style={styles.rowText}>
        <AppText variant="caption">{label}</AppText>
        <AppText variant="bodyBold" color={highlight ? colors.success : colors.text}>{value}</AppText>
      </View>
    </View>
  );
}

export default function ProfileScreen() {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();

  // nextDate: موعد التبرع القادم. eligibleNow: true إذا مر وقت الراحة أو ما تبرع قبل
  const nextDate = getNextEligibleDate(user.lastDonationDate);
  const eligibleNow = !nextDate || nextDate <= new Date();
  const hasEligibility = user.lastDonationDate !== undefined; // undefined = السيرفر ما بعت الحقل

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.content}>
        <FadeInView style={styles.top}>
          <Avatar name={user.name} size={96} />
          <AppText variant="title">{user.name}</AppText>
        </FadeInView>

        <FadeInView delay={150}>
          <Card>
            <InfoRow icon="phone-portrait-outline" label={t('profile.phone')} value={user.phone} />
            <InfoRow icon="water-outline" label={t('profile.bloodType')} value={user.bloodType} last={!user.city && !hasEligibility} />
            {/* المدينة وموعد التبرع بيظهروا بس إذا السيرفر بعتهم (ما بنعرض معلومة مش مؤكدة) */}
            {user.city ? <InfoRow icon="location-outline" label={t('profile.city')} value={t(`cities.${user.city}`)} last={!hasEligibility} /> : null}
            {hasEligibility ? (
              <InfoRow
                icon="calendar-outline"
                label={t('profile.nextDonation')}
                value={eligibleNow ? t('profile.eligibleNow') : formatDate(nextDate, i18n.language)}
                highlight={eligibleNow}
                last
              />
            ) : null}
          </Card>
        </FadeInView>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.md, gap: spacing.md },
  top: { alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.md },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md - 4 },
  divider: { borderBottomWidth: 1, borderBottomColor: colors.border },
  iconBox: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.primarySoft, alignItems: 'center', justifyContent: 'center' },
  rowText: { flex: 1 },
});
