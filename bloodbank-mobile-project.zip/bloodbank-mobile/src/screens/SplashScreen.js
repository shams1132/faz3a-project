// شاشة الافتتاح (Splash): قطرة الدم على خلفية داكنة، وبعد ثانيتين بتختفي لحالها.
import { useEffect } from 'react';
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import BloodDrop from '../components/BloodDrop';
import FadeInView from '../components/FadeInView';
import { colors, gradients, spacing } from '../theme';

// onFinish: دالة بتنادي لما نخلص (App.js بيعرف إنه وقت الانتقال)
export default function SplashScreen({ onFinish }) {
  const { t } = useTranslation();

  useEffect(() => {
    const timer = setTimeout(onFinish, 2400);
    return () => clearTimeout(timer); // تنظيف: إذا انغلقت الشاشة قبل الوقت
  }, []);

  return (
    <LinearGradient colors={gradients.dark} style={styles.container}>
      {/* دوائر ديكور خلف القطرة */}
      <View style={styles.glow} />
      <FadeInView style={styles.center}>
        <BloodDrop size={110} animated />
        <AppText variant="display" color={colors.white} style={styles.name}>{t('app.name')}</AppText>
        <AppText variant="body" color="rgba(255,255,255,0.75)">{t('app.slogan')}</AppText>
      </FadeInView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  glow: { position: 'absolute', width: 340, height: 340, borderRadius: 170, backgroundColor: 'rgba(196,18,47,0.25)' },
  center: { alignItems: 'center' },
  name: { marginTop: spacing.lg },
});
