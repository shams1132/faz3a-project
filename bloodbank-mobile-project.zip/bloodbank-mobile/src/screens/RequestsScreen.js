// تبويب الطلبات: قائمة طلبات الدم المتوافقة، مع تبويب داخلي (النشطة / السابقة).
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import EmptyState from '../components/EmptyState';
import ErrorState from '../components/ErrorState';
import RequestCard from '../components/RequestCard';
import ScreenBackground from '../components/ScreenBackground';
import TabHeader from '../components/TabHeader';
import { useAuth } from '../context/AuthContext';
import { getCompatibleRequests } from '../services/requestsService';
import { colors, radius, shadow, spacing } from '../theme';

export default function RequestsScreen({ navigation }) {
  const { t } = useTranslation();
  const { user } = useAuth();

  const [requests, setRequests] = useState([]);
  const [tab, setTab] = useState('active'); // 'active' أو 'past'
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(false);

  async function loadRequests() {
    try {
      setError(false);
      setRequests(await getCompatibleRequests(user.bloodType));
    } catch {
      setError(true);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  useFocusEffect(useCallback(() => { loadRequests(); }, [user.bloodType]));

  // النشطة = ما انتهت. السابقة = اللي حالتها DONE.
  const visible = requests.filter((r) => (tab === 'active' ? r.status !== 'DONE' : r.status === 'DONE'));

  return (
    <ScreenBackground>
      <TabHeader title={t('requests.title')} />

      {/* التبويب الداخلي */}
      <View style={styles.tabs}>
        {['active', 'past'].map((key) => (
          <Pressable key={key} onPress={() => setTab(key)} style={[styles.tab, tab === key && styles.tabActive]}>
            <AppText variant="bodyBold" color={tab === key ? colors.white : colors.textLight}>{t(`requests.${key}`)}</AppText>
          </Pressable>
        ))}
      </View>

      {loading ? (
        <View style={styles.center}><ActivityIndicator size="large" color={colors.primary} /></View>
      ) : error ? (
        <ErrorState onRetry={loadRequests} />
      ) : (
        <FlatList
          contentContainerStyle={styles.list}
          data={visible}
          keyExtractor={(item) => String(item.id)}
          // كل عنصر = كارد طلب، وضغطته بتفتح التفاصيل وبتبعتلها الطلب كامل
          renderItem={({ item }) => <RequestCard request={item} onPress={() => navigation.navigate('RequestDetails', { request: item })} />}
          // بيظهر لما القائمة فاضية
          ListEmptyComponent={<EmptyState message={t(tab === 'active' ? 'requests.emptyActive' : 'requests.emptyPast')} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); loadRequests(); }} tintColor={colors.primary} />}
        />
      )}
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  tabs: { flexDirection: 'row', backgroundColor: colors.white, borderRadius: radius.full, padding: 4, marginHorizontal: spacing.md, marginBottom: spacing.md, ...shadow.card },
  tab: { flex: 1, paddingVertical: 9, alignItems: 'center', borderRadius: radius.full },
  tabActive: { backgroundColor: colors.primary },
  list: { paddingHorizontal: spacing.md, paddingBottom: spacing.xl },
});
