// تبويب "المزيد": بطاقة المستخدم + قائمة (معلوماتي، السجل، الإعدادات، الدعم، تسجيل الخروج).
import { Alert, ScrollView, StyleSheet, View } from 'react-native';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Avatar from '../components/Avatar';
import BloodBadge from '../components/BloodBadge';
import Card from '../components/Card';
import FadeInView from '../components/FadeInView';
import MenuRow from '../components/MenuRow';
import ScreenBackground from '../components/ScreenBackground';
import TabHeader from '../components/TabHeader';
import { useAuth } from '../context/AuthContext';
import { spacing } from '../theme';

export default function MoreScreen({ navigation }) {
  const { t } = useTranslation();
  const { user, signOut } = useAuth();

  // بنسأل قبل تسجيل الخروج
  function confirmLogout() {
    Alert.alert(t('more.logout'), t('more.logoutConfirm'), [
      { text: t('common.cancel'), style: 'cancel' },
      { text: t('common.confirm'), onPress: signOut },
    ]);
  }

  return (
    <ScreenBackground>
      <TabHeader title={t('tabs.more')} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <FadeInView>
          <Card style={styles.userCard}>
            <Avatar name={user.name} size={64} />
            <View style={styles.userInfo}>
              <AppText variant="heading">{user.name}</AppText>
              <AppText variant="caption">{user.city ? `${t(`cities.${user.city}`)} • ` : ''}{user.phone}</AppText>
            </View>
            <BloodBadge type={user.bloodType} size={48} />
          </Card>
        </FadeInView>

        <FadeInView delay={120}>
          <Card>
            <MenuRow icon="person-outline" label={t('more.personal')} onPress={() => navigation.navigate('Profile')} />
            <MenuRow icon="time-outline" label={t('more.history')} onPress={() => navigation.navigate('History')} />
            <MenuRow icon="settings-outline" label={t('more.settings')} onPress={() => navigation.navigate('Settings')} />
            <MenuRow icon="help-buoy-outline" label={t('more.help')} onPress={() => navigation.navigate('Help')} />
            <MenuRow icon="log-out-outline" label={t('more.logout')} onPress={confirmLogout} danger last />
          </Card>
        </FadeInView>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: spacing.md, paddingBottom: spacing.xl, gap: spacing.md },
  userCard: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  userInfo: { flex: 1 },
});
