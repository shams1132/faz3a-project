// الإعدادات: اللغة (شغالة فعلاً)، المدينة (من حسابك)، ومعلومات التطبيق.
// شلنا مفاتيح "الإشعارات" و"متوفر للتبرع" لأنها ما كانت بتأثر على شي حقيقي.
import { ScrollView, StyleSheet } from 'react-native';
import { useTranslation } from 'react-i18next';
import AppText from '../components/AppText';
import Card from '../components/Card';
import LanguageSwitcher from '../components/LanguageSwitcher';
import MenuRow from '../components/MenuRow';
import ScreenBackground from '../components/ScreenBackground';
import { useAuth } from '../context/AuthContext';
import { colors, spacing } from '../theme';

export default function SettingsScreen() {
  const { t } = useTranslation();
  const { user } = useAuth();

  return (
    <ScreenBackground>
      <ScrollView contentContainerStyle={styles.content}>
        <Card>
          <MenuRow icon="globe-outline" label={t('settings.language')} right={<LanguageSwitcher />} />
          {/* المدينة: بتظهر بس إذا الحساب فيه مدينة */}
          {user.city ? (
            <MenuRow icon="location-outline" label={t('settings.city')} right={<AppText variant="bodyBold" color={colors.textLight}>{t(`cities.${user.city}`)}</AppText>} />
          ) : null}
          <MenuRow icon="information-circle-outline" label={t('settings.about')} right={<AppText variant="caption">{t('settings.version')}</AppText>} last />
        </Card>
      </ScrollView>
    </ScreenBackground>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.md, gap: spacing.md },
});
