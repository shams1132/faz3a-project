// مين بيقدر يتبرع لمين. المفتاح = فصيلة المتبرع، والقيمة = الفصائل اللي بيقدر يعطيها.
const CAN_DONATE_TO = {
  'O-': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
  'O+': ['O+', 'A+', 'B+', 'AB+'],
  'A-': ['A-', 'A+', 'AB-', 'AB+'],
  'A+': ['A+', 'AB+'],
  'B-': ['B-', 'B+', 'AB-', 'AB+'],
  'B+': ['B+', 'AB+'],
  'AB-': ['AB-', 'AB+'],
  'AB+': ['AB+'],
};

// بترجع true إذا المتبرع بيقدر يتبرع للفصيلة المطلوبة
export function canDonateTo(donorType, requestedType) {
  return (CAN_DONATE_TO[donorType] || []).includes(requestedType);
}
