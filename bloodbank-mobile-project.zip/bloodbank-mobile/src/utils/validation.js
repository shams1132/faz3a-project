// رقم جوال فلسطيني: 10 أرقام وبيبدأ بـ 05
export const isValidPhone = (phone) => /^05\d{8}$/.test(phone);

// هل الخطأ سببه بيانات دخول غلط؟ (وإلا يعني مشكلة نت أو سيرفر)
export const isAuthError = (err) =>
  err?.message === 'INVALID_CREDENTIALS' || err?.response?.status === 401;
