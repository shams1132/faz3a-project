// بتأخّر شوي عشان نحاكي وقت الإنترنت بالبيانات الوهمية
export const wait = (ms = 600) => new Promise((resolve) => setTimeout(resolve, ms));
