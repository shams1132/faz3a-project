import { ELIGIBILITY_DAYS } from '../config';

// بتحول التاريخ لنص مقروء حسب اللغة (أرقام إنجليزية بالنسختين)
export function formatDate(value, language) {
  const date = new Date(value);
  try {
    const locale = language === 'ar' ? 'ar-u-nu-latn' : 'en-GB';
    return date.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' });
  } catch {
    return date.toISOString().slice(0, 10); // خطة بديلة إذا الجهاز ما دعم اللغة
  }
}

// موعد التبرع القادم = آخر تبرع + عدد أيام الراحة. بترجع null إذا ما تبرع قبل.
export function getNextEligibleDate(lastDonationDate) {
  if (!lastDonationDate) return null;
  const date = new Date(lastDonationDate);
  date.setDate(date.getDate() + ELIGIBILITY_DAYS);
  return date;
}

// "منذ ساعتين" / "2 h ago": بتحسب الفرق بين الآن والتاريخ، وبتختار الوحدة المناسبة.
// t = دالة الترجمة (بنمررها من الشاشة).
export function timeAgo(value, t) {
  const minutes = Math.floor((Date.now() - new Date(value).getTime()) / 60000);
  if (minutes < 1) return t('time.justNow');
  if (minutes < 60) return t('time.minutes', { count: minutes });
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return t('time.hours', { count: hours });
  const days = Math.floor(hours / 24);
  if (days < 30) return t('time.days', { count: days });
  return t('time.months', { count: Math.floor(days / 30) });
}
