// بيانات وهمية للتجربة. لما نربط الباك اند ما بنستخدم هاد الملف.
// شكل الحقول (id, bloodType, status...) لازم نطابقه مع توثيق الـ API لما يجهز.
// كل الأسماء بالعربي.

const hoursAgo = (h) => new Date(Date.now() - h * 3600 * 1000).toISOString();
const daysAgo = (d) => hoursAgo(d * 24);

// المستخدم الوهمي (متبرع). lastDonationDate = null إذا ما تبرع قبل.
export const mockUser = {
  id: 1,
  name: 'ريم أحمد',
  phone: '0599123456',
  bloodType: 'O+',
  city: 'jenin',
  lastDonationDate: daysAgo(30),
};

// طلبات الدم الوهمية. معنى الحقول:
// bloodType = الفصيلة المطلوبة | urgency = URGENT عاجل أو NORMAL عادي
// status = PENDING مطلوب، ON_THE_WAY في الطريق، DONE تم
// unitsNeeded / unitsOnTheWay / unitsDone = عدد الوحدات (مطلوب / بالطريق / تم)
// notes = ملاحظة من المستشفى | myResponse = رد هالمتبرع على الطلب (null = ما رد)
export const mockRequests = [
  { id: 1, bloodType: 'O-', urgency: 'URGENT', status: 'PENDING', unitsNeeded: 4, unitsOnTheWay: 2, unitsDone: 1, notes: 'مريض بحاجة لعملية جراحية عاجلة', createdAt: hoursAgo(2), myResponse: null },
  { id: 2, bloodType: 'O+', urgency: 'URGENT', status: 'PENDING', unitsNeeded: 3, unitsOnTheWay: 1, unitsDone: 0, notes: 'حالة ولادة طارئة', createdAt: hoursAgo(5), myResponse: null },
  { id: 3, bloodType: 'A+', urgency: 'NORMAL', status: 'PENDING', unitsNeeded: 2, unitsOnTheWay: 0, unitsDone: 0, notes: '', createdAt: hoursAgo(20), myResponse: null },
  { id: 4, bloodType: 'AB+', urgency: 'NORMAL', status: 'DONE', unitsNeeded: 1, unitsOnTheWay: 0, unitsDone: 1, notes: '', createdAt: daysAgo(3), myResponse: null },
  { id: 5, bloodType: 'B-', urgency: 'URGENT', status: 'PENDING', unitsNeeded: 2, unitsOnTheWay: 0, unitsDone: 0, notes: 'مريض غسيل كلى', createdAt: hoursAgo(8), myResponse: null },
  { id: 6, bloodType: 'O+', urgency: 'NORMAL', status: 'DONE', unitsNeeded: 2, unitsOnTheWay: 0, unitsDone: 2, notes: 'تم تأمين الوحدات، شكراً للمتبرعين', createdAt: daysAgo(6), myResponse: null },
];

// سجل التبرعات الوهمي
export const mockDonations = [
  { id: 1, bloodType: 'O+', units: 1, date: daysAgo(30) },
  { id: 2, bloodType: 'O+', units: 1, date: daysAgo(130) },
  { id: 3, bloodType: 'O+', units: 1, date: daysAgo(260) },
];
