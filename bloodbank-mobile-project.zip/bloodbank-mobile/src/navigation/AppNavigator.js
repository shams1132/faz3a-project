// خريطة التنقل: لو المستخدم مسجّل بنعرض التطبيق، وإلا بنعرض الترحيب/الدخول/التسجيل.
import { ActivityIndicator, StyleSheet, View } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import WelcomeScreen from '../screens/WelcomeScreen';
import LoginScreen from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import HomeScreen from '../screens/HomeScreen';
import RequestsScreen from '../screens/RequestsScreen';
import MoreScreen from '../screens/MoreScreen';
import RequestDetailsScreen from '../screens/RequestDetailsScreen';
import SuccessScreen from '../screens/SuccessScreen';
import SettingsScreen from '../screens/SettingsScreen';
import HelpScreen from '../screens/HelpScreen';
import ProfileScreen from '../screens/ProfileScreen';
import DonationHistoryScreen from '../screens/DonationHistoryScreen';
import { colors, fonts, shadow } from '../theme';

// Stack: تنقل بنفتح فيه الشاشة فوق الشاشة اللي قبلها، وزر الرجوع بيطلع لحاله.
const Stack = createNativeStackNavigator();
// Tab: الشريط السفلي اللي فيه التبويبات.
const Tab = createBottomTabNavigator();

// اسم أيقونة لكل تبويب (من مكتبة Ionicons). بنضيف -outline لما التبويب مش مفعّل.
const TAB_ICONS = { Home: 'home', Requests: 'water', More: 'grid' };

// الشريط السفلي: 3 تبويبات
function MainTabs() {
  const { t } = useTranslation();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false, // كل تبويب بيرسم عنوانه بنفسه
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textLight,
        tabBarStyle: styles.tabBar,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ focused, color, size }) => (
          <Ionicons name={focused ? TAB_ICONS[route.name] : `${TAB_ICONS[route.name]}-outline`} size={size} color={color} />
        ),
      })}
    >
      {/* كل Tab.Screen = تبويب. name = اسمه، component = الشاشة، title = النص الظاهر (مترجم) */}
      <Tab.Screen name="Home" component={HomeScreen} options={{ title: t('tabs.home') }} />
      <Tab.Screen name="Requests" component={RequestsScreen} options={{ title: t('tabs.requests') }} />
      <Tab.Screen name="More" component={MoreScreen} options={{ title: t('tabs.more') }} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const { t } = useTranslation();
  const { user, loading } = useAuth();

  // بنستنى نعرف إذا في مستخدم محفوظ قبل ما نقرر أي شاشات نعرض
  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  // شكل شريط العنوان لكل الشاشات الداخلية (شفاف بدون خط، بخط Cairo)
  const headerOptions = {
    headerTitleAlign: 'center',
    headerShadowVisible: false,
    headerStyle: { backgroundColor: '#FFF7F7' },
    headerTitleStyle: { fontFamily: fonts.bold, fontSize: 18, color: colors.text },
    headerTintColor: colors.primary,
    headerBackButtonDisplayMode: 'minimal',
  };

  return (
    <Stack.Navigator screenOptions={headerOptions}>
      {/* إذا المستخدم مسجّل: شاشات التطبيق. وإلا: شاشات الدخول. التبديل بيصير تلقائياً. */}
      {user ? (
        <>
          {/* Main = الشريط السفلي كامل. headerShown: false لأنه كل تبويب إله عنوانه */}
          <Stack.Screen name="Main" component={MainTabs} options={{ headerShown: false }} />
          {/* RequestDetails: بنفتحها من الرئيسية أو الطلبات وبنبعتلها الطلب كامل */}
          <Stack.Screen name="RequestDetails" component={RequestDetailsScreen} options={{ title: t('details.title') }} />
          <Stack.Screen name="Success" component={SuccessScreen} options={{ headerShown: false, gestureEnabled: false }} />
          <Stack.Screen name="Settings" component={SettingsScreen} options={{ title: t('settings.title') }} />
          <Stack.Screen name="Help" component={HelpScreen} options={{ title: t('help.title') }} />
          <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: t('profile.title') }} />
          <Stack.Screen name="History" component={DonationHistoryScreen} options={{ title: t('history.title') }} />
        </>
      ) : (
        <>
          <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Register" component={RegisterScreen} options={{ headerShown: false }} />
        </>
      )}
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  loading: { flex: 1, justifyContent: 'center' },
  tabBar: { height: 68, paddingTop: 6, paddingBottom: 10, backgroundColor: colors.white, borderTopWidth: 0, ...shadow.card },
  tabLabel: { fontFamily: fonts.semi, fontSize: 11 },
});
