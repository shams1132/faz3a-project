// إعداد الترجمة (عربي / إنجليزي) والاتجاه (RTL / LTR).
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { I18nManager, DevSettings } from 'react-native';
import { getLocales } from 'expo-localization';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Updates from 'expo-updates';
import ar from './ar.json';
import en from './en.json';

const LANGUAGE_KEY = 'app_language';
const RELOAD_TRIED_KEY = 'direction_reload_tried';

// إعادة تشغيل التطبيق (لازمة عشان الاتجاه يتغير)
async function reloadApp() {
  try {
    await Updates.reloadAsync();
  } catch {
    DevSettings.reload(); // بوضع التطوير (Expo Go)
  }
}

// بنغير اتجاه التطبيق إذا ما كان مطابق للغة
async function applyDirection(language) {
  const shouldBeRTL = language === 'ar';

  if (I18nManager.isRTL === shouldBeRTL) {
    await AsyncStorage.removeItem(RELOAD_TRIED_KEY);
    return;
  }

  // حماية: إذا جربنا إعادة التشغيل مرة وما زبط، ما نكرر (عشان ما ندخل بحلقة)
  const alreadyTried = await AsyncStorage.getItem(RELOAD_TRIED_KEY);
  if (alreadyTried) return;

  await AsyncStorage.setItem(RELOAD_TRIED_KEY, '1');
  I18nManager.allowRTL(shouldBeRTL);
  I18nManager.forceRTL(shouldBeRTL);
  await reloadApp();
}

// بتنادى مرة وحدة عند بداية التطبيق
export async function setupI18n() {
  const saved = await AsyncStorage.getItem(LANGUAGE_KEY);
  const deviceLanguage = getLocales()[0]?.languageCode;
  // اللغة: المحفوظة، وإلا لغة الجهاز، وإلا العربي
  const language = saved || (deviceLanguage === 'en' ? 'en' : 'ar');

  // init: بنعرّف اللغات المتوفرة (resources) واللغة الحالية (lng)،
  // وfallbackLng هي اللغة البديلة إذا نص ناقص.
  await i18n.use(initReactI18next).init({
    resources: { ar: { translation: ar }, en: { translation: en } },
    lng: language,
    fallbackLng: 'ar',
    interpolation: { escapeValue: false },
  });

  await applyDirection(language);
}

// بتنادى لما المستخدم يبدل اللغة
export async function changeLanguage(language) {
  await AsyncStorage.setItem(LANGUAGE_KEY, language);
  await i18n.changeLanguage(language);
  await AsyncStorage.removeItem(RELOAD_TRIED_KEY);
  await applyDirection(language);
}

export default i18n;
