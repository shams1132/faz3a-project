// تسجيل الدخول وإنشاء الحساب.
// كل دالة فيها فرعين: بيانات وهمية (USE_MOCK) أو الباك اند الحقيقي.
// مسارات الـ API (/auth/login ...) تخمين، لازم نطابقها مع توثيق الباك اند.
import api from './api';
import { USE_MOCK } from '../config';
import { mockUser } from '../data/mockData';
import { wait } from '../utils/wait';

// بترجع { token, user }
export async function login(phone, password) {
  if (USE_MOCK) {
    await wait();
    if (password.length < 6) throw new Error('INVALID_CREDENTIALS');
    return { token: 'mock-token', user: { ...mockUser, phone } };
  }
  const response = await api.post('/auth/login', { phone, password });
  return response.data;
}

export async function register({ name, phone, password, bloodType, city }) {
  if (USE_MOCK) {
    await wait();
    return {
      token: 'mock-token',
      user: { id: 99, name, phone, bloodType, city, lastDonationDate: null },
    };
  }
  const response = await api.post('/auth/register', { name, phone, password, bloodType, city });
  return response.data;
}
