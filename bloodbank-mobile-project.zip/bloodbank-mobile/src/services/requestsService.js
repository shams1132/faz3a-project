// كل ما يخص طلبات الدم.
import api from './api';
import { USE_MOCK, DONOR_RESPONSE } from '../config';
import { mockRequests } from '../data/mockData';
import { canDonateTo } from '../utils/bloodCompatibility';
import { wait } from '../utils/wait';

// الطلبات المتوافقة مع فصيلة المتبرع (العاجل أول، وبعدين الأحدث)
export async function getCompatibleRequests(bloodType) {
  if (USE_MOCK) {
    await wait();
    return mockRequests
      .filter((r) => canDonateTo(bloodType, r.bloodType))
      .sort((a, b) => {
        if (a.urgency !== b.urgency) return a.urgency === 'URGENT' ? -1 : 1;
        return new Date(b.createdAt) - new Date(a.createdAt);
      })
      .map((r) => ({ ...r }));
  }
  // الباك اند بيعرف المتبرع من التوكن، فما بنبعت الفصيلة
  const response = await api.get('/requests/compatible');
  return response.data;
}

// رد المتبرع: DONOR_RESPONSE.ON_THE_WAY أو DONOR_RESPONSE.DECLINED
export async function respondToRequest(id, donorResponse) {
  if (USE_MOCK) {
    await wait();
    const request = mockRequests.find((r) => r.id === id);
    request.myResponse = donorResponse;
    if (donorResponse === DONOR_RESPONSE.ON_THE_WAY) request.unitsOnTheWay += 1;
    return;
  }
  // الشاشة بتحدّث الأرقام عندها بنفسها، فما بنعتمد على شكل جواب السيرفر
  await api.post(`/requests/${id}/respond`, { response: donorResponse }); // مسار تخمين
}
