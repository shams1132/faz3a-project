// سجل تبرعات المتبرع.
import api from './api';
import { USE_MOCK } from '../config';
import { mockDonations } from '../data/mockData';
import { wait } from '../utils/wait';

export async function getMyDonations() {
  if (USE_MOCK) {
    await wait();
    return mockDonations;
  }
  const response = await api.get('/donations/mine');
  return response.data;
}
